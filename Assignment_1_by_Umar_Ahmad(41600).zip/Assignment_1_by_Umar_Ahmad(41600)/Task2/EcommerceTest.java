public class EcommerceTest {
    public static void main(String[] args) {

        Product product1 = new Product("1", "Ear Birds", 349.591, 70);
        Product product2 = new Product("2", "HeadPhones", 129.121, 10);
        Product product3 = new Product("3", "Mobile Cover", 132.967, 90);
        
        product1.applyDiscount(10);  
        product2.applyDiscount(5);   
        product3.applyDiscount(150); 

        Customer customer1 = new Customer("C1", "Umar");
        Customer customer2 = new Customer("C2", "Ali");
        
        customer1.purchase(product1, 2);  
        customer2.purchase(product2, 1);  
        customer1.purchase(product3, 10); 
        customer2.purchase(product1, 3);  

        System.out.println("\nUpdated product details:");
        product1.printDetails();
        product2.printDetails();
        product3.printDetails();

        System.out.println("Total products created: " + Product.totalProducts);
    }
}

class Product {
    String productId;
    String productName;
    double price;
    int stockQuantity;
    static int totalProducts = 0; 
    
    public Product() {
        this.productId = "Unknown";
        this.productName = "Generic Product";
        this.price = 0.0;
        this.stockQuantity = 0;
        totalProducts++;
    }
    
    public Product(String productId, String productName, double price, int stockQuantity) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.stockQuantity = stockQuantity;
        totalProducts++;
    }
    
    public void applyDiscount(double percentage) {
        if (percentage > 0 && percentage <= 100) {
            price = price - (price * (percentage / 100));
            System.out.println("Discount applied: New price of '" + productName + "' is " + price);
        } else {
            System.out.println("Invalid discount percentage.");
        }
    }
    
    public boolean isAvailable(int quantity) {
        return stockQuantity >= quantity;
    }
    
    public void sell(int quantity) {
        if (isAvailable(quantity)) {
            stockQuantity -= quantity;
            System.out.println("Sold " + quantity + " of '" + productName + "'. Remaining stock: " + stockQuantity);
        } else {
            System.out.println("Insufficient stock for product: " + productName);
        }
    }
    
    public void printDetails() {
        System.out.println("Product ID: " + productId + ", Name: " + productName + ", Price: " + price + ", Stock: " + stockQuantity);
    }
}
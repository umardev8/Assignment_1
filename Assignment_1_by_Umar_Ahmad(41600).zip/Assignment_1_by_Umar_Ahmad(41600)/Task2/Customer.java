class Customer {
    String customerId;
    String customerName;
    double totalPurchases;
    
    public Customer(String customerId, String customerName) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.totalPurchases = 0.0;
    }
    
    public void purchase(Product product, int quantity) {
        if (product.isAvailable(quantity)) {
            product.sell(quantity); 
            totalPurchases += product.price * quantity; 
            System.out.println(customerName + " purchased " + quantity + " of '" + product.productName + "'. Total spent: " + totalPurchases);
        } else {
            System.out.println("Insufficient stock for '" + product.productName + "'. Purchase not completed.");
        }
    }
}
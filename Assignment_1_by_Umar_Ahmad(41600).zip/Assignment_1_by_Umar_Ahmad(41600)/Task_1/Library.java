class Library {
    String name;
    String address;
    Book[] books;
    int bookCount;

    public Library(String name, String address) {
        this.name = name;
        this.address = address;
        this.books = new Book[100];
        this.bookCount = 0;
    }
    
    public void addBook(Book book) {
        if (bookCount < 100) {
            books[bookCount++] = book;
            System.out.println("Book '" + book.title + "' added to the library.");
        } else {
            System.out.println("Library is full, cannot add more books.");
        }
    }
    
    public void searchByAuthor(String author) {
        boolean found = false;
        System.out.println("Books by author '" + author + "':");
        for (int i = 0; i < bookCount; i++) {
            if (books[i].author.equalsIgnoreCase(author)) {
                books[i].printDetails();
                found = true;
            }
        }
        if (!found) {
            System.out.println("No books found by the author '" + author + "'.");
        }
    }
    
    public void showAvailableBooks() {
        boolean found = false;
        System.out.println("Available books:");
        for (int i = 0; i < bookCount; i++) {
            if (!books[i].isIssued) {
                books[i].printDetails();
                found = true;
            }
        }
        if (!found) {
            System.out.println("No available books in the library.");
        }
    }
}
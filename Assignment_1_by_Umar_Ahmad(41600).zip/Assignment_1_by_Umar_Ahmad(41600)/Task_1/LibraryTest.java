public class LibraryTest {
    public static void main(String[] args) {

        Library myLibrary = new Library("Iqra Uni Library", "IQRA UNI H9");
        
        Book book1 = new Book("Java Programming", "Umar", "41600", 5000);
        Book book2 = new Book("DSA", "Saim", "41537", 3000);
        Book book3 = new Book("App Development", "Ali", "43215", 7000);
        
        myLibrary.addBook(book1);
        myLibrary.addBook(book2);
        myLibrary.addBook(book3);
        
        book1.issueBook();
        book1.returnBook();
        
        myLibrary.searchByAuthor("Umar");
        
        myLibrary.showAvailableBooks();
        
        System.out.println("Total books created: " + Book.totalBooks);
    }
}
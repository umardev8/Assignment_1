
class Book {
    String title;
    String author;
    String isbn;
    double price;
    boolean isIssued;
    static int totalBooks = 0; 
    
    public Book() {
        this.title = "";
        this.author = "";
        this.isbn = "";
        this.price = 0.0;
        this.isIssued = false;
        totalBooks++;
    }
    
    public Book(String title, String author, String isbn, double price) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.price = price;
        this.isIssued = false;
        totalBooks++;
    }
    
    public void issueBook() {
        if (!isIssued) {
            isIssued = true;
            System.out.println("Book '" + title + "' has been issued.");
        } else {
            System.out.println("Book '" + title + "' is already issued.");
        }
    }
    
    public void returnBook() {
        if (isIssued) {
            isIssued = false;
            System.out.println("Book '" + title + "' has been returned.");
        } else {
            System.out.println("Book '" + title + "' was not issued.");
        }
    }
    
    public void printDetails() {
        System.out.println("Title: " + title + ", Author: " + author + ", ISBN: " + isbn + ", Price: " + price + ", Issued: " + (isIssued ? "Yes" : "No"));
    }
}
